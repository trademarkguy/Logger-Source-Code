module.export = { 
    Logger:
    'your token here'   
}
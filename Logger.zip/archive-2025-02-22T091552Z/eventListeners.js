const { Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const fs = require('fs');
const path = require('path');
const config = require(path.join(__dirname, 'tokens.js'));
const token = config.Logger;
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.MessageContent
    ],
    shards: "auto",
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Reaction,
        Partials.GuildScheduledEvent,
        Partials.User,
        Partials.ThreadMember
    ]
});
const guildConfigsPath = path.join(__dirname, 'guildConfigs.json');

function readGuildConfigs() {
    try {
        const fileContent = fs.readFileSync(guildConfigsPath, 'utf8');
        return JSON.parse(fileContent);
    } catch (error) {
        console.error(`Error reading ${guildConfigsPath}:`, error);
        return [];
    }
}
async function logEvent(logType, subject, action, timestamp, guild, user, message, thumbnail, color) {
    try {
         const translatedMessage = await getTranslatedMessage(logType, guild);
        const guildConfigs = readGuildConfigs();
        const guildConfig = guildConfigs.find(config => config.guildId === guild.id);

        if (!guildConfig || !guildConfig.loggingChannelId) {
            return;
        }

        const loggingChannelId = guildConfig.loggingChannelId;
        const loggingChannel = await client.channels.fetch(loggingChannelId);

        if (!loggingChannel || !loggingChannel.isTextBased()) {
            return;
        }

        if (guildConfig.bypassRoleId && guild.members.cache.get(user.id)?.roles.cache.has(guildConfig.bypassRoleId)) {
            return;
        }

        if (message && message.channel && guildConfig.bypassChannelId && message.channel.id === guildConfig.bypassChannelId) {
            return;
        }

        const loggingEmbed = new EmbedBuilder()
            .setTitle(translatedMessage)
            .setDescription(action)
            .setTimestamp(timestamp);

        if (color) {
            loggingEmbed.setColor(color);
        }

        if (typeof thumbnail === 'string' && thumbnail !== '') {
            loggingEmbed.setThumbnail(thumbnail);
        }

        await loggingChannel.send({ embeds: [loggingEmbed] });
    } catch (error) {
        console.error('Error logging event:', error);
    }
}
const guildConfigs = require('./guildConfigs.json'); // Make sure this path is correct

async function getTranslatedMessage(messageKey, guildId) {
    const guildConfigs = readGuildConfigs();
    const languageCode = guildConfigs.find(config => config.guildId === guildId)?.language || 'en';
    const translations = {
    en: {
        'Message Deleted': 'Message Deleted',
        'Deleted': 'Deleted',
        'Message Edited': 'Message Edited',
        'Edited': 'Edited',
        'Role Created': 'Role Created',
        'Created': 'Created',
        'Role Deleted': 'Role Deleted',
        'Role Permissions Updated': 'Role Permissions Updated',
        'Updated': 'Updated',
        'Role Name Updated': 'Role Name Updated',
        'Name Changed': 'Name Changed',
        'Role Color Updated': 'Role Color Updated',
        'Color Changed': 'Color Changed',
        'Username Updated': 'Username Updated',
        'Username Changed': 'Username Changed',
        'Avatar Updated': 'Avatar Updated',
        'Avatar Changed': 'Avatar Changed',
        'Discriminator Updated': 'Discriminator Updated',
        'Discriminator Changed': 'Discriminator Changed',
        'Role Added': 'Role Added',
        'Added': 'Added',
        'Role Removed': 'Role Removed',
        'Removed': 'Removed',
        'Server Name Changed': 'Server Name Changed',
        'Server Icon Changed': 'Server Icon Changed',
        'Server Banner Changed': 'Server Banner Changed',
        'Emoji Created': 'Emoji Created',
        'Emoji Deleted': 'Emoji Deleted',
        'Sticker Created': 'Sticker Created',
        'Sticker Deleted': 'Sticker Deleted',
        'Member Joined': 'Member Joined',
        'Joined': 'Joined',
        'Member Left': 'Member Left',
        'Left': 'Left',
        'Started Streaming': 'Started Streaming',
        'Stream Started': 'Stream Started',
        'Stopped Streaming': 'Stopped Streaming',
        'Stream Stopped': 'Stream Stopped',
        'Voice Channel Joined': 'Voice Channel Joined',
        'Voice Channel Left': 'Voice Channel Left',
        'Voice Channel Switch': 'Voice Channel Switch',
        'Channel Created': 'Channel Created',
        'Channel Deleted': 'Channel Deleted',
        'Channel Renamed': 'Channel Renamed',
        'Channel Permissions Updated': 'Channel Permissions Updated',
    },
    fr: {
        'Message Deleted': 'Message Supprimé',
        'Deleted': 'Supprimé',
        'Message Edited': 'Message Édité',
        'Edited': 'Édité',
        'Role Created': 'Rôle Créé',
        'Created': 'Créé',
        'Role Deleted': 'Rôle Supprimé',
        'Role Permissions Updated': 'Permissions du Rôle Mises à Jour',
        'Updated': 'Mises à Jour',
        'Role Name Updated': 'Nom du Rôle Mis à Jour',
        'Name Changed': 'Nom Changé',
        'Role Color Updated': 'Couleur du Rôle Mise à Jour',
        'Color Changed': 'Couleur Changée',
        'Username Updated': 'Nom d’Utilisateur Mis à Jour',
        'Username Changed': 'Nom d’Utilisateur Changé',
        'Avatar Updated': 'Avatar Mis à Jour',
        'Avatar Changed': 'Avatar Changé',
        'Discriminator Updated': 'Discriminateur Mis à Jour',
        'Discriminator Changed': 'Discriminateur Changé',
        'Role Added': 'Rôle Ajouté',
        'Added': 'Ajouté',
        'Role Removed': 'Rôle Retiré',
        'Removed': 'Retiré',
        'Server Name Changed': 'Nom du Serveur Changé',
        'Server Icon Changed': 'Icône du Serveur Changée',
        'Server Banner Changed': 'Bannière du Serveur Changée',
        'Emoji Created': 'Émoji Créé',
        'Emoji Deleted': 'Émoji Supprimé',
        'Sticker Created': 'Autocollant Créé',
        'Sticker Deleted': 'Autocollant Supprimé',
        'Member Joined': 'Membre Rejoint',
        'Joined': 'Rejoint',
        'Member Left': 'Membre Parti',
        'Left': 'Parti',
        'Started Streaming': 'Début de Streaming',
        'Stream Started': 'Streaming Commencé',
        'Stopped Streaming': 'Arrêt du Streaming',
        'Stream Stopped': 'Streaming Arrêté',
        'Voice Channel Joined': 'Canal Vocal Rejoint',
        'Voice Channel Left': 'Canal Vocal Quitte',
        'Voice Channel Switch': 'Changement de Canal Vocal',
        'Channel Created': 'Canal Créé',
        'Channel Deleted': 'Canal Supprimé',
        'Channel Renamed': 'Canal Renommé',
        'Channel Permissions Updated': 'Permissions du Canal Mises à Jour',
    },
    de: {
        'Message Deleted': 'Nachricht Gelöscht',
        'Deleted': 'Gelöscht',
        'Message Edited': 'Nachricht Bearbeitet',
        'Edited': 'Bearbeitet',
        'Role Created': 'Rolle Erstellt',
        'Created': 'Erstellt',
        'Role Deleted': 'Rolle Gelöscht',
        'Role Permissions Updated': 'Rollenberechtigungen Aktualisiert',
        'Updated': 'Aktualisiert',
        'Role Name Updated': 'Rollenname Aktualisiert',
        'Name Changed': 'Name Geändert',
        'Role Color Updated': 'Rollenfarbe Aktualisiert',
        'Color Changed': 'Farbe Geändert',
        'Username Updated': 'Benutzername Aktualisiert',
        'Username Changed': 'Benutzername Geändert',
        'Avatar Updated': 'Avatar Aktualisiert',
        'Avatar Changed': 'Avatar Geändert',
        'Discriminator Updated': 'Discriminator Aktualisiert',
        'Discriminator Changed': 'Discriminator Geändert',
        'Role Added': 'Rolle Hinzugefügt',
        'Added': 'Hinzugefügt',
        'Role Removed': 'Rolle Entfernt',
        'Removed': 'Entfernt',
        'Server Name Changed': 'Servername Geändert',
        'Server Icon Changed': 'Server-Icon Geändert',
        'Server Banner Changed': 'Server-Banner Geändert',
        'Emoji Created': 'Emoji Erstellt',
        'Emoji Deleted': 'Emoji Gelöscht',
        'Sticker Created': 'Sticker Erstellt',
        'Sticker Deleted': 'Sticker Gelöscht',
        'Member Joined': 'Mitglied Beigetreten',
        'Joined': 'Beigetreten',
        'Member Left': 'Mitglied Verlassen',
        'Left': 'Verlassen',
        'Started Streaming': 'Streaming Gestartet',
        'Stream Started': 'Stream Gestartet',
        'Stopped Streaming': 'Streaming Beendet',
        'Stream Stopped': 'Stream Beendet',
        'Voice Channel Joined': 'Sprachkanal Betreten',
        'Voice Channel Left': 'Sprachkanal Verlassen',
        'Voice Channel Switch': 'Wechsel des Sprachkanals',
        'Channel Created': 'Kanal Erstellt',
        'Channel Deleted': 'Kanal Gelöscht',
        'Channel Renamed': 'Kanal Umbenannt',
        'Channel Permissions Updated': 'Kanalberechtigungen Aktualisiert',
    },
    es: {
        'Message Deleted': 'Mensaje Eliminado',
        'Deleted': 'Eliminado',
        'Message Edited': 'Mensaje Editado',
        'Edited': 'Editado',
        'Role Created': 'Rol Creado',
        'Created': 'Creado',
        'Role Deleted': 'Rol Eliminado',
        'Role Permissions Updated': 'Permisos del Rol Actualizados',
        'Updated': 'Actualizados',
        'Role Name Updated': 'Nombre del Rol Actualizado',
        'Name Changed': 'Nombre Cambiado',
        'Role Color Updated': 'Color del Rol Actualizado',
        'Color Changed': 'Color Cambiado',
        'Username Updated': 'Nombre de Usuario Actualizado',
        'Username Changed': 'Nombre de Usuario Cambiado',
        'Avatar Updated': 'Avatar Actualizado',
        'Avatar Changed': 'Avatar Cambiado',
        'Discriminator Updated': 'Discriminador Actualizado',
        'Discriminator Changed': 'Discriminador Cambiado',
        'Role Added': 'Rol Añadido',
        'Added': 'Añadido',
        'Role Removed': 'Rol Eliminado',
        'Removed': 'Eliminado',
        'Server Name Changed': 'Nombre del Servidor Cambiado',
        'Server Icon Changed': 'Ícono del Servidor Cambiado',
        'Server Banner Changed': 'Banner del Servidor Cambiado',
        'Emoji Created': 'Emoji Creado',
        'Emoji Deleted': 'Emoji Eliminado',
        'Sticker Created': 'Sticker Creado',
        'Sticker Deleted': 'Sticker Eliminado',
        'Member Joined': 'Miembro Unido',
        'Joined': 'Unido',
        'Member Left': 'Miembro Salió',
        'Left': 'Salió',
        'Started Streaming': 'Empezó a Transmitir',
        'Stream Started': 'Transmisión Iniciada',
        'Stopped Streaming': 'Dejó de Transmitir',
        'Stream Stopped': 'Transmisión Detenida',
        'Voice Channel Joined': 'Canal de Voz Unido',
        'Voice Channel Left': 'Canal de Voz Abandonado',
        'Voice Channel Switch': 'Cambio de Canal de Voz',
        'Channel Created': 'Canal Creado',
        'Channel Deleted': 'Canal Eliminado',
        'Channel Renamed': 'Canal Renombrado',
        'Channel Permissions Updated': 'Permisos del Canal Actualizados',
    },
    hi: {
        'Message Deleted': 'संदेश हटाया गया',
        'Deleted': 'हटाया गया',
        'Message Edited': 'संदेश संपादित किया गया',
        'Edited': 'संपादित किया गया',
        'Role Created': 'भूमिका बनाई गई',
        'Created': 'बनाई गई',
        'Role Deleted': 'भूमिका हटाई गई',
        'Role Permissions Updated': 'भूमिका अनुमतियाँ अपडेट की गई',
        'Updated': 'अपडेट की गई',
        'Role Name Updated': 'भूमिका नाम अपडेट किया गया',
        'Name Changed': 'नाम बदला गया',
        'Role Color Updated': 'भूमिका रंग अपडेट किया गया',
        'Color Changed': 'रंग बदला गया',
        'Username Updated': 'उपयोगकर्ता नाम अपडेट किया गया',
        'Username Changed': 'उपयोगकर्ता नाम बदला गया',
        'Avatar Updated': 'अवतार अपडेट किया गया',
        'Avatar Changed': 'अवतार बदला गया',
        'Discriminator Updated': 'डिस्क्रिमिनेटर अपडेट किया गया',
        'Discriminator Changed': 'डिस्क्रिमिनेटर बदला गया',
        'Role Added': 'भूमिका जोड़ी गई',
        'Added': 'जोड़ी गई',
        'Role Removed': 'भूमिका हटा दी गई',
        'Removed': 'हटा दी गई',
        'Server Name Changed': 'सर्वर का नाम बदला गया',
        'Server Icon Changed': 'सर्वर आइकन बदला गया',
        'Server Banner Changed': 'सर्वर बैनर बदला गया',
        'Emoji Created': 'इमोजी बनाया गया',
        'Emoji Deleted': 'इमोजी हटाया गया',
        'Sticker Created': 'स्टिकर बनाया गया',
        'Sticker Deleted': 'स्टिकर हटाया गया',
        'Member Joined': 'सदस्य शामिल हुआ',
        'Joined': 'शामिल हुआ',
        'Member Left': 'सदस्य छोड़ दिया',
        'Left': 'छोड़ दिया',
        'Started Streaming': 'स्ट्रीमिंग शुरू की',
        'Stream Started': 'स्ट्रीमिंग शुरू की',
        'Stopped Streaming': 'स्ट्रीमिंग बंद की',
        'Stream Stopped': 'स्ट्रीमिंग बंद की',
        'Voice Channel Joined': 'वॉयस चैनल में शामिल हुआ',
        'Voice Channel Left': 'वॉयस चैनल छोड़ा',
        'Voice Channel Switch': 'वॉयस चैनल स्विच',
        'Channel Created': 'चैनल बनाया गया',
        'Channel Deleted': 'चैनल हटाया गया',
        'Channel Renamed': 'चैनल का नाम बदल गया',
        'Channel Permissions Updated': 'चैनल अनुमतियाँ अपडेट की गई',
    },
};

    return translations[languageCode][messageKey] || messageKey;
}

client.on('messageDelete', async message => {
    const guildId = message.guild.id;
    const translatedTitle = await getTranslatedMessage('Message Deleted', guildId);
    const translatedDescription = await getTranslatedMessage('Deleted', guildId);
    const content = message.content ? message.content : 'Message content unavailable';
    const author = message.author ? message.author.id : 'Unknown Author';
    const authorAvatarURL = message.author ? message.author.displayAvatarURL() : null;
    const channel = message.channel ? message.channel.id : 'Unknown Channel';
    const color = 0xFF0000;

    logEvent(translatedTitle, translatedDescription, `"${content}" sent by <@${author}> in <#${channel}>`, new Date(), message.guild, message.author, message, authorAvatarURL, color);
});

client.on('messageUpdate', async (oldMessage, newMessage) => {
    if (oldMessage.content === newMessage.content) return;

    const guildId = newMessage.guild.id;
    const translatedTitle = await getTranslatedMessage('Message Edited', guildId);
    const translatedDescription = await getTranslatedMessage('Edited', guildId);
    const oldContent = oldMessage.content ? oldMessage.content : 'Message content unavailable';
    const newContent = newMessage.content ? newMessage.content : 'Message content unavailable';
    const author = newMessage.author ? newMessage.author.id : 'Unknown Author';
    const authorAvatarURL = newMessage.author ? newMessage.author.displayAvatarURL() : null;
    const channel = newMessage.channel ? newMessage.channel.id : 'Unknown Channel';
    const color = 0x00FF00;

    logEvent(translatedTitle, translatedDescription, `"${oldContent}" edited to "${newContent}" by <@${author}> in <#${channel}>`, new Date(), newMessage.guild, newMessage.author, newMessage, authorAvatarURL, color);
});

client.on('roleCreate', async role => {
    try {
        const guildId = role.guild.id;
        const translatedTitle = await getTranslatedMessage('Role Created', guildId);
        const translatedDescription = await getTranslatedMessage('Created', guildId);

        const auditLogs = await role.guild.fetchAuditLogs({ type: 30 });
        const entry = auditLogs.entries.first();
        const executor = entry ? entry.executor : 'Unknown';

        const executorAvatar = entry && executor.displayAvatarURL ? executor.displayAvatarURL({ dynamic: true }) : role.guild.iconURL();
        const color = 0x00FF00;

        logEvent(translatedTitle, translatedDescription, `"${role}" created by ${executor}`, new Date(), role.guild, executor, role, executorAvatar, color);
    } catch (error) {
        console.error('Error fetching audit logs:', error);
        const guildId = role.guild.id;
        const translatedTitle = await getTranslatedMessage('Role Created', guildId);
        const translatedDescription = await getTranslatedMessage('Created', guildId);
        const color = 0x00FF00;

        logEvent(translatedTitle, translatedDescription, `"${role}" created by "Unknown"`, new Date(), role.guild, role.guild.iconURL(), role, null, color);
    }
});

client.on('roleDelete', async role => {
    const guildId = role.guild.id;
    const translatedTitle = await getTranslatedMessage('Role Deleted', guildId);
    const translatedDescription = await getTranslatedMessage('Deleted', guildId);
    const color = 0xFF0000;

    logEvent(translatedTitle, translatedDescription, `"${role}" deleted`, new Date(), role.guild, role.guild.iconURL(), role, null, color);
});

client.on('roleUpdate', async (oldRole, newRole) => {
    const guildId = oldRole.guild.id;
    const translatedTitle = await getTranslatedMessage('Role Updated', guildId);
    const translatedDescription = await getTranslatedMessage('Updated', guildId);
    const color = 0x00FFFF;

    let changes = '';
    if (oldRole.name !== newRole.name) changes += `Name changed from "${oldRole.name}" to "${newRole.name}". `;
    if (oldRole.color !== newRole.color) changes += `Color changed from "${oldRole.color}" to "${newRole.color}". `;
    if (oldRole.permissions.bitfield !== newRole.permissions.bitfield) changes += `Permissions changed.`;

    logEvent(translatedTitle, translatedDescription, changes, new Date(), oldRole.guild, oldRole.guild.iconURL(), newRole, null, color);
});

client.on('guildMemberUpdate', async (oldMember, newMember) => {
    const guildId = newMember.guild.id;
    const translatedTitle = await getTranslatedMessage('Member Updated', guildId);
    const translatedDescription = await getTranslatedMessage('Updated', guildId);
    const color = 0xFFFF00;

    let changes = '';
    if (oldMember.nickname !== newMember.nickname) changes += `Nickname changed from "${oldMember.nickname}" to "${newMember.nickname}". `;
    if (oldMember.roles.cache.size !== newMember.roles.cache.size) changes += `Roles updated.`;

    logEvent(translatedTitle, translatedDescription, changes, new Date(), newMember.guild, newMember.user, newMember, newMember.user.displayAvatarURL(), color);
});

client.on('channelCreate', async channel => {
    const guildId = channel.guild.id;
    const translatedTitle = await getTranslatedMessage('Channel Created', guildId);
    const translatedDescription = await getTranslatedMessage('Created', guildId);
    const color = 0x00FF00;

    logEvent(translatedTitle, translatedDescription, `"${channel.name}" created`, new Date(), channel.guild, channel.guild.iconURL(), channel, null, color);
});

client.on('channelDelete', async channel => {
    const guildId = channel.guild.id;
    const translatedTitle = await getTranslatedMessage('Channel Deleted', guildId);
    const translatedDescription = await getTranslatedMessage('Deleted', guildId);
    const color = 0xFF0000;

    logEvent(translatedTitle, translatedDescription, `"${channel.name}" deleted`, new Date(), channel.guild, channel.guild.iconURL(), channel, null, color);
});

client.on('channelUpdate', async (oldChannel, newChannel) => {
    const guildId = oldChannel.guild.id;
    const translatedTitle = await getTranslatedMessage('Channel Updated', guildId);
    const translatedDescription = await getTranslatedMessage('Updated', guildId);
    const color = 0x00FFFF;

    let changes = '';
    if (oldChannel.name !== newChannel.name) changes += `Name changed from "${oldChannel.name}" to "${newChannel.name}". `;
    if (oldChannel.topic !== newChannel.topic) changes += `Topic changed.`;

    logEvent(translatedTitle, translatedDescription, changes, new Date(), oldChannel.guild, oldChannel.guild.iconURL(), newChannel, null, color);
});

client.on('guildUpdate', async (oldGuild, newGuild) => {
    const guildId = newGuild.id;
    const translatedTitle = await getTranslatedMessage('Server Updated', guildId);
    const translatedDescription = await getTranslatedMessage('Updated', guildId);
    const color = 0xFFFF00;

    let changes = '';
    if (oldGuild.name !== newGuild.name) changes += `Name changed from "${oldGuild.name}" to "${newGuild.name}". `;
    if (oldGuild.icon !== newGuild.icon) changes += `Icon changed. `;
    if (oldGuild.banner !== newGuild.banner) changes += `Banner changed.`;

    logEvent(translatedTitle, translatedDescription, changes, new Date(), newGuild, newGuild.iconURL(), newGuild, null, color);
});

client.on('emojiCreate', async emoji => {
    const guildId = emoji.guild.id;
    const translatedTitle = await getTranslatedMessage('Emoji Created', guildId);
    const translatedDescription = await getTranslatedMessage('Created', guildId);
    const color = 0x00FF00;

    logEvent(translatedTitle, translatedDescription, `"${emoji.name}" created`, new Date(), emoji.guild, emoji.guild.iconURL(), emoji, null, color);
});

client.on('emojiDelete', async emoji => {
    const guildId = emoji.guild.id;
    const translatedTitle = await getTranslatedMessage('Emoji Deleted', guildId);
    const translatedDescription = await getTranslatedMessage('Deleted', guildId);
    const color = 0xFF0000;

    logEvent(translatedTitle, translatedDescription, `"${emoji.name}" deleted`, new Date(), emoji.guild, emoji.guild.iconURL(), emoji, null, color);
});

client.on('stickerCreate', async sticker => {
    const guildId = sticker.guild.id;
    const translatedTitle = await getTranslatedMessage('Sticker Created', guildId);
    const translatedDescription = await getTranslatedMessage('Created', guildId);
    const color = 0x00FF00;

    logEvent(translatedTitle, translatedDescription, `"${sticker.name}" created`, new Date(), sticker.guild, sticker.guild.iconURL(), sticker, null, color);
});

client.on('stickerDelete', async sticker => {
    const guildId = sticker.guild.id;
    const translatedTitle = await getTranslatedMessage('Sticker Deleted', guildId);
    const translatedDescription = await getTranslatedMessage('Deleted', guildId);
    const color = 0xFF0000;

    logEvent(translatedTitle, translatedDescription, `"${sticker.name}" deleted`, new Date(), sticker.guild, sticker.guild.iconURL(), sticker, null, color);
});

client.on('voiceStateUpdate', async (oldState, newState) => {
    const guildId = newState.guild.id;
    const translatedTitle = await getTranslatedMessage('Voice Channel Update', guildId);
    const translatedDescription = await getTranslatedMessage('Voice Channel Switch', guildId);
    const color = 0xFFFF00;

    let changes = '';
    if (!oldState.channel && newState.channel) changes += await getTranslatedMessage(`<@${newState.member.user.id}> Joined voice channel "${newState.channel.name}". `, guildId);
    if (oldState.channel && !newState.channel) changes += await getTranslatedMessage(`<@${newState.member.user.id}> Left voice channel "${oldState.channel.name}". `, guildId);
    if (oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id) changes += await getTranslatedMessage(`<@${newState.member.user.id}> Switched from voice channel "${oldState.channel.name}" to "${newState.channel.name}".`, guildId);

    logEvent(translatedTitle, translatedDescription, changes, new Date(), newState.guild, newState.member.user, newState, newState.member.user.displayAvatarURL(), color);
});

client.on('guildBanAdd', async (guild, user) => {
    try {
        const auditLogs = await guild.fetchAuditLogs({ type: 22 });
        const entry = auditLogs.entries.first();
        if (entry) {
            const banner = entry.executor;
            const guildAvatarURL = guild.iconURL({ dynamic: true });
            const color = 0xFF0000;
            const translatedTitle = await getTranslatedMessage('Member Banned', guild.id);
            const translatedDescription = await getTranslatedMessage('Banned', guild.id);
            const translatedMessage = await getTranslatedMessage(`${user} was banned from the server. Banned by: ${banner}`, guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), guild, user, null, guildAvatarURL, color);
        }
    } catch (error) {
        console.error("Error handling member ban:", error);
    }
});

client.on('guildBanRemove', async (guild, user) => {
    try {
        const auditLogs = await guild.fetchAuditLogs({ type: 23 });
        const entry = auditLogs.entries.first();
        if (entry) {
            const unbanner = entry.executor;
            const guildAvatarURL = guild.iconURL({ dynamic: true });
            const color = 0x00FF00;
            const translatedTitle = await getTranslatedMessage('Member Unbanned', guild.id);
            const translatedDescription = await getTranslatedMessage('Unbanned', guild.id);
            const translatedMessage = await getTranslatedMessage(`${user} was unbanned from the server. Unbanned by: ${unbanner}`, guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), guild, user, null, guildAvatarURL, color);
        }
    } catch (error) {
        console.error("Error handling member unban:", error);
    }
});

client.on('channelUpdate', async (oldChannel, newChannel) => {
    try {
        function formatPermissionName(permission) {
            return permission
                .replace(/_/g, ' ')
                .replace(/([a-z])([A-Z])/g, '$1 $2')
                .split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
        }

        const oldPermissions = oldChannel.permissionOverwrites.cache.map(over => over.allow.toArray()).flat().sort();
        const newPermissions = newChannel.permissionOverwrites.cache.map(over => over.allow.toArray()).flat().sort();

        const addedPermissions = newPermissions.filter(permission => !oldPermissions.includes(permission));
        const removedPermissions = oldPermissions.filter(permission => !newPermissions.includes(permission));
        const unchangedPermissions = oldPermissions.filter(permission => newPermissions.includes(permission));

        const changes = [];

        for (const permission of addedPermissions) {
            const translatedPermission = await getTranslatedMessage(formatPermissionName(permission), newChannel.guild.id);
            changes.push(`:white_check_mark: **${translatedPermission}**`);
        }

        for (const permission of removedPermissions) {
            const translatedPermission = await getTranslatedMessage(formatPermissionName(permission), newChannel.guild.id);
            changes.push(`:negative_squared_cross_mark: **${translatedPermission}**`);
        }

        if (changes.length > 0) {
            const auditLogs = await newChannel.guild.fetchAuditLogs({ type: 14 });
            const entry = auditLogs.entries.first();
            if (entry) {
                const executor = entry.executor;
                const color = 0x00FF00;
                const thumbnail = executor.displayAvatarURL();
                const translatedTitle = await getTranslatedMessage('Channel Permissions Updated:', newChannel.guild.id);
                const translatedDescription = await getTranslatedMessage('Updated', newChannel.guild.id);
                const translatedMessage = await getTranslatedMessage(`${oldChannel} permissions updated by ${executor}\n\n${changes.join('\n')}`, newChannel.guild.id);
                logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), oldChannel.guild, executor, null, thumbnail, color);
            }
        } 
    } catch (error) {
        console.error("Error handling channel permissions update:", error);
    }
});

client.on('channelUpdate', async (oldChannel, newChannel) => {
    try {
        if (oldChannel.name !== newChannel.name) {
            const auditLogs = await newChannel.guild.fetchAuditLogs({ type: 11 });
            const entry = auditLogs.entries.first();
            if (entry) {
                const executor = entry.executor;
                const color = 0x00FF00;
                const translatedTitle = await getTranslatedMessage('Channel Renamed', newChannel.guild.id);
                const translatedDescription = await getTranslatedMessage('Renamed', newChannel.guild.id);
                const translatedMessage = await getTranslatedMessage(`Channel renamed from "${oldChannel.name}" to "${newChannel.name}" by ${executor}`, newChannel.guild.id);
                const thumbnail = executor.displayAvatarURL();
                logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), newChannel.guild, executor, null, thumbnail, color);
            }
        }
    } catch (error) {
        console.error("Error handling channel rename:", error);
    }
});

client.on('channelCreate', async channel => {
    try {
        const auditLogs = await channel.guild.fetchAuditLogs({ type: 10 });
        const entry = auditLogs.entries.first();
        if (entry) {
            const creator = entry.executor;
            const color = 0x00FF00;
            const translatedTitle = await getTranslatedMessage('Channel Created', channel.guild.id);
            const translatedDescription = await getTranslatedMessage('Created', channel.guild.id);
            const translatedMessage = await getTranslatedMessage(`Channel ${channel} created by ${creator}`, channel.guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), channel.guild, creator, null, creator.displayAvatarURL(), color);
        } else {
            const translatedTitle = await getTranslatedMessage('Channel Created', channel.guild.id);
            const translatedDescription = await getTranslatedMessage('Created', channel.guild.id);
            const translatedMessage = await getTranslatedMessage(`Channel ${channel} created by Unknown`, channel.guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), channel.guild, null, null, null);
        }
    } catch (error) {
        console.error("Error handling channel creation:", error);
    }
});

client.on('channelDelete', async channel => {
    try {
        const auditLogs = await channel.guild.fetchAuditLogs({ type: 12 });
        const entry = auditLogs.entries.first();
        if (entry) {
            const deleter = entry.executor;
            const color = 0xFF0000;
            const translatedTitle = await getTranslatedMessage('Channel Deleted', channel.guild.id);
            const translatedDescription = await getTranslatedMessage('Deleted', channel.guild.id);
            const translatedMessage = await getTranslatedMessage(`Channel "${channel.name}" deleted by ${deleter}`, channel.guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), channel.guild, deleter, null, deleter.displayAvatarURL(), color);
        } else {
            const translatedTitle = await getTranslatedMessage('Channel Deleted', channel.guild.id);
            const translatedDescription = await getTranslatedMessage('Deleted', channel.guild.id);
            const translatedMessage = await getTranslatedMessage(`Channel ${channel.name} deleted by Unknown`, channel.guild.id);
            logEvent(translatedTitle, translatedDescription, translatedMessage, new Date(), channel.guild, null, null, null);
        }
    } catch (error) {
        console.error("Error handling channel deletion:", error);
    }
});

client.once('ready', async () => {
    console.log(`Event Listeners Deployed`);
    const numberOfServers = client.guilds.cache.size;
    const users = client.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);
    client.user.setPresence({
        activities: [{ name: `${numberOfServers} servers and ${users} users!`, type: 3 }],
        status: 'dnd'
    });
});
client.login(token);
const { Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const eventListeners = require('./eventListeners');
const insertCommands = require('./commands');
const fs = require('fs');
const path = require('path');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.MessageContent
    ],
    shards: "auto",
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Reaction,
        Partials.GuildScheduledEvent,
        Partials.User,
        Partials.ThreadMember
    ]
});

const guildConfigsPath = path.join(__dirname, 'guildConfigs.json');

function readGuildConfigs() {
    try {
        const fileContent = fs.readFileSync(guildConfigsPath, 'utf8');
        return JSON.parse(fileContent);
    } catch (error) {
        console.error(`Error reading ${guildConfigsPath}:`, error);
        return [];
    }
}

function writeGuildConfigs(guildConfigs) {
    try {
        fs.writeFileSync(guildConfigsPath, JSON.stringify(guildConfigs, null, 2), 'utf8');
    } catch (error) {
        console.error(`Error writing to ${guildConfigsPath}:`, error);
    }
}
function getGuildConfig(guildId) {
    const guildConfigs = readGuildConfigs();
    return guildConfigs.find(config => config.guildId === guildId) || {};
}
function setGuildConfig(guildId, loggingChannelId, bypassRoleId, bypassChannelId, language = 'en') {
    let guildConfigs = readGuildConfigs();
    const existingIndex = guildConfigs.findIndex(config => config.guildId === guildId);
    const now = new Date().toISOString();

    if (existingIndex !== -1) {
        guildConfigs[existingIndex] = {
            ...guildConfigs[existingIndex],
            loggingChannelId,
            bypassRoleId,
            bypassChannelId,
            language, // Set the language preference
            updatedAt: now
        };
    } else {
        guildConfigs.push({
            guildId,
            loggingChannelId,
            bypassRoleId,
            bypassChannelId,
            language, // Set the language preference
            createdAt: now,
            updatedAt: now
        });
    }

    writeGuildConfigs(guildConfigs);
}
async function performDatabaseBackup() {
    try {
        const guildConfigs = readGuildConfigs();
        const jsonData = JSON.stringify(guildConfigs, null, 2);
        fs.writeFileSync('database_backup.txt', jsonData);

        const backupChannelIds = ['1228326025856024667', '1229084412512047186'];
        for (const channelId of backupChannelIds) {
            const backupChannel = await client.channels.fetch(channelId);
            if (backupChannel) {
                backupChannel.send({ files: ['database_backup.txt'] });
            } else {
                console.error('Database backup channel not found or not a text channel.');
            }
        }
    } catch (error) {
        console.error('Error performing database backup:', error);
    }
}

(async () => {
    try {
        setInterval(performDatabaseBackup, 3600000);
    } catch (error) {
        console.error("Error performing backups:", error);
    }
})();

module.exports = { client, setGuildConfig };

async function setBypassRole(guildId, roleId) {
    const guildConfigs = readGuildConfigs();
    const guildConfig = guildConfigs.find(config => config.guildId === guildId);
    if (!guildConfig) return;

    const bypassRoles = guildConfig.bypassRoleId ? guildConfig.bypassRoleId.split(',') : [];
    if (!bypassRoles.includes(roleId)) {
        bypassRoles.push(roleId);
        guildConfig.bypassRoleId = bypassRoles.join(',');
        writeGuildConfigs(guildConfigs);
    }
}

async function setBypassChannel(guildId, channelId) {
    const guildConfigs = readGuildConfigs();
    const guildConfig = guildConfigs.find(config => config.guildId === guildId);
    if (!guildConfig) return;

    const bypassChannels = guildConfig.bypassChannelId ? guildConfig.bypassChannelId.split(',') : [];
    if (!bypassChannels.includes(channelId)) {
        bypassChannels.push(channelId);
        guildConfig.bypassChannelId = bypassChannels.join(',');
        writeGuildConfigs(guildConfigs);
    }
}

function removeBypass(guildId) {
    let guildConfigs = readGuildConfigs();
    const existingIndex = guildConfigs.findIndex(config => config.guildId === guildId);

    if (existingIndex !== -1) {
        delete guildConfigs[existingIndex].bypassRoleId;
        delete guildConfigs[existingIndex].bypassChannelId;
        guildConfigs[existingIndex].updatedAt = new Date().toISOString();
    }

    writeGuildConfigs(guildConfigs);
}

async function removeBypassChannel(guildId, channelId) {
    const guildConfigs = readGuildConfigs();
    const guildConfig = guildConfigs.find(config => config.guildId === guildId);
    if (!guildConfig || !guildConfig.bypassChannelId) return;

    const bypassChannels = guildConfig.bypassChannelId.split(',').filter(id => id !== channelId);
    guildConfig.bypassChannelId = bypassChannels.join(',');
    writeGuildConfigs(guildConfigs);
}

function getBypassList(guildId) {
    const guildConfig = getGuildConfig(guildId);
    return {
        bypassRoleId: guildConfig.bypassRoleId || null,
        bypassChannelId: guildConfig.bypassChannelId || null
    };
}
const config = require(path.join(__dirname, 'tokens.js'));
const token = config.Logger;
const rest = new REST({ version: '9' }).setToken(token);
(async () => {
    try {

        await Promise.all(client.guilds.cache.map(guild => insertCommands(guild)));

    } catch (error) {
        console.error('Error refreshing application (/) commands:', error);
    }
})();

const crashNotificationUserId = '622382966504685580';
async function sendCrashNotification(error) {
    try {
        const user = await client.users.fetch(crashNotificationUserId);
        await user.send(`The bot crashed with the following error code: ${error}`);
        console.log('Crash notification sent to user:', crashNotificationUserId);
    } catch (err) {
        console.error('Error sending crash notification:', err);
    }
}
process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
    sendCrashNotification(err);
});

const blacklistedGuildsFilePath = path.join(__dirname, 'blacklisted_guild_ids.json');
const blacklistedUsersFilePath = path.join(__dirname, 'blacklisted_user_ids.json');

let blacklistedGuildIds = require(blacklistedGuildsFilePath);
let blacklistedUserIds = require(blacklistedUsersFilePath);

async function checkGuildBan(guild) {
    const owner = await guild.fetchOwner();
    const guildInfo = { name: guild.name, id: guild.id };

    if (blacklistedGuildIds.includes(guild.id)) {
        await notifyAndLeave('guild', owner.id, guildInfo);
    } else if (blacklistedUserIds.includes(owner.id)) {
        await notifyAndLeave('user', owner.id, guildInfo);
    }
}

async function notifyAndLeave(reason, userId, guildInfo) {
    const user = await client.users.fetch(userId);
    const message = reason === 'guild'
        ? `Your guild (*${guildInfo.name}*, *${guildInfo.id}*) has been banned from Logger. For more information or to appeal, please contact \`@fwtrademark\` \`(622382966504685580)\`.`
        : `You have been banned from Logger. For more information or to appeal, please contact \`@fwtrademark\` \`(622382966504685580)\`.`;

    await user.send(message);
    const guild = client.guilds.cache.get(guildInfo.id);
    if (guild) await guild.leave();
}

client.on('guildCreate', checkGuildBan);

client.on('messageCreate', async message => {
    if (message.author.id !== '622382966504685580') return;

    const args = message.content.split(' ');
    const command = args.shift().toLowerCase();

    if (command === '-guildban') {
        const guildId = args[0];
        if (!blacklistedGuildIds.includes(guildId)) {
            blacklistedGuildIds.push(guildId);
            fs.writeFileSync(blacklistedGuildsFilePath, JSON.stringify(blacklistedGuildIds, null, 2));

            const guild = client.guilds.cache.get(guildId);
            if (guild) await checkGuildBan(guild);

            await message.channel.send(`<:Yes:1259426548692418591> Guild ID \`${guildId}\` has been banned.`);
        }
    } else if (command === '-guildunban') {
        const guildId = args[0];
        blacklistedGuildIds = blacklistedGuildIds.filter(id => id !== guildId);
        fs.writeFileSync(blacklistedGuildsFilePath, JSON.stringify(blacklistedGuildIds, null, 2));
        await message.channel.send(`<:Yes:1259426548692418591> Guild ID \`${guildId}\` has been unbanned.`);
    } else if (command === '-userban') {
        const userId = args[0];
        if (!blacklistedUserIds.includes(userId)) {
            blacklistedUserIds.push(userId);
            fs.writeFileSync(blacklistedUsersFilePath, JSON.stringify(blacklistedUserIds, null, 2));

            client.guilds.cache.forEach(async guild => {
                const owner = await guild.fetchOwner();
                if (owner.id === userId) {
                    await notifyAndLeave('user', userId, { name: guild.name, id: guild.id });
                }
            });

            await message.channel.send(`<:Yes:1259426548692418591> User ID \`${userId}\` has been banned.`);
        }
    } else if (command === '-userunban') {
        const userId = args[0];
        blacklistedUserIds = blacklistedUserIds.filter(id => id !== userId);
        fs.writeFileSync(blacklistedUsersFilePath, JSON.stringify(blacklistedUserIds, null, 2));
        await message.channel.send(`<:Yes:1259426548692418591> User ID \`${userId}\` has been unbanned.`);
    } else if (command === '-banlist') {
        const embed = new EmbedBuilder()
            .setTitle('Bot Ban List:')
            .setColor(0xff0000)
            .addFields(
                { name: 'User ID\'s', value: blacklistedUserIds.join('\n') || 'None' },
                { name: 'Guild ID\'s', value: blacklistedGuildIds.join('\n') || 'None' }
            )
            .setTimestamp();
        await message.channel.send({ embeds: [embed] });
    }
});

async function insertCommandsToAllGuilds() {
    try {
        await Promise.all(client.guilds.cache.map(guild => insertCommands(guild)));
    } catch (error) {
        console.error('Error inserting slash commands to all guilds:', error);
    }
}

client.on('guildCreate', async guild => {
    const trademark = '622382966504685580';
    const numberOfServers = client.guilds.cache.size;
    const user = await client.users.fetch(trademark);
    const newGuildUsers = guild.memberCount;
    const totalUsers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
    
    await user.send(`# GG lil bro we joined another server, now we in ${numberOfServers} servers, that new server had ${newGuildUsers} users now we have ${totalUsers} users`);
    
    client.user.setPresence({
        activities: [{ name: `${numberOfServers} servers and ${totalUsers} users!`, type: 3 }],
        status: 'dnd'
    });
});

const backupchannelIds = ['1223293659835793560'];
const backupFolder = __dirname;
const filesToSend = ['package-lock.json', 'package.json', 'tokens.js', 'logger.js', 'commands.js', 'guildConfigs.json', 'logger.txt'];
const interval = 3600000;

async function sendFolderContents() {
    for (const channelId of backupchannelIds) {
        const channel = await client.channels.fetch(channelId);
        if (!channel) {
            console.error(`Invalid channel ID: ${channelId}`);
            continue;
        }

        for (const file of filesToSend) {
            const filePath = path.join(backupFolder, file);
            if (!fs.existsSync(filePath)) {
                console.error(`File not found: ${filePath}`);
                continue;
            }

            fs.readFile(filePath, (err, data) => {
                if (err) {
                    console.error(`Error reading file ${file}:`, err);
                    return;
                }
                channel.send({ content: `Hourly Backup: ${file}`, files: [{ attachment: data, name: file }] })
                    .catch(console.error);
            });
        }
    }
}
function updateBotPresence() {
    const numberOfServers = client.guilds.cache.size;
    const totalUsers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
    
    client.user.setPresence({
        activities: [{ name: `${numberOfServers} servers and ${totalUsers} users!`, type: 3 }],
        status: 'dnd'
    });
}
let startTime;
client.once('ready', async guild => {
    const numberOfServers = client.guilds.cache.size;
    const users = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
    console.log(`Logged in as ${client.user.tag}. GG WE'RE IN ${numberOfServers} SERVERS!`);
    client.user.setPresence({
        activities: [{ name: `${numberOfServers} servers and ${users} users!`, type: 3 }],
        status: 'dnd'
    });
    setInterval(sendFolderContents, interval);
    setInterval(updateBotPresence, 3600000);
    startTime = Date.now();
});
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName, options, user, guild, channel } = interaction;
    const numberOfServers = client.guilds.cache.size;
    const botThumbnail = "https://media.discordapp.net/attachments/1131985511662235650/1227781895715291146/discord-avatar-128-LP4KS.gif?ex=6629a7ff&is=661732ff&hm=86bb90ef008815bd4ae9e2ad3af3275a966518ac4955e96b88e337b431a201ff&";
        let InfouptimeString = '';

    switch (commandName) {
 case 'setlanguage':      
    try {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            await interaction.reply({ content: '`Administrator` permission not found.', ephemeral: true });
            return;
        }

        const languageCode = interaction.options.getString('language');
        const guildId = interaction.guild.id;
        const guildConfigs = readGuildConfigs(); // Ensure this function is defined
        const guildConfig = guildConfigs.find(config => config.guildId === guildId);

        // Check if logging channel is set
        if (!guildConfig || !guildConfig.loggingChannelId) {
            await interaction.reply({ content: 'Please set a logging channel first. (Tip: set one using `/log`).', ephemeral: true });
            return;
        }

        setGuildConfig(guildId, guildConfig.loggingChannelId, guildConfig.bypassRoleId, guildConfig.bypassChannelId, languageCode);

        await interaction.reply({ content: `Language set to ${interaction.options.getString('language')}.`, ephemeral: true });
    } catch (error) {
        console.error('Error setting language:', error);
        await interaction.reply({ content: 'There was an error setting the language.', ephemeral: true });
    }
    break;
        case 'support':
            const supportEmbed = new EmbedBuilder()
            .setTitle('Support')
            .setDescription(`**Ways you can reach support:**

DM'ing: "**@fwtrademark**"

Joining Support Server: https://discord.gg/zjS4vhS8PX`)
            .setThumbnail(botThumbnail)
            .setTimestamp();
            
            interaction.reply({ embeds: [supportEmbed], ephemeral: true});
            break;
case 'ping':
    await interaction.reply({ content: 'Pinging...', ephemeral: true });

    const clientPing = Math.round(client.ws.ping);

    await interaction.editReply({ content: `🏓 Pong! Ping is ${clientPing}ms.`, ephemeral: true });
    break;
        case 'suggest':
await interaction.reply({ content: 'Suggestion sent to developers.', ephemeral: true });
            const suggestion = options.getString('suggestion');

            const suggestionEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setTitle('New Suggestion')
                .setDescription(suggestion)
                .setFooter({ text: `Sent from ${guild.name} by ${user.tag}`})
                .setThumbnail(guild.iconURL({ dynamic: true }))
                .setTimestamp();

            const suggestionChannel = client.channels.cache.get('1232713402577719326');
            if (suggestionChannel) {
                suggestionChannel.send(`**Guild ID:** ${guild.id}
**User ID:** ${user.id} • <@${user.id}>`).then(() => {
                    suggestionChannel.send({ embeds: [suggestionEmbed] });
                });
            }
            break;
case 'log':
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
       interaction.reply({ content: '`Administrator` permission not found.', ephemeral: true });
        return;
    }

    const loggingChannel = options.getChannel('channel');

    const guildConfig = getGuildConfig(interaction.guild.id);

    if (!loggingChannel) {
        if (guildConfig && guildConfig.loggingChannelId) {
            const currentLoggingChannel = await client.channels.fetch(guildConfig.loggingChannelId);
            if (currentLoggingChannel) {
await interaction.reply({ content: 'Logging feature disabled.', ephemeral: true });
            }
            setGuildConfig(interaction.guild.id, null, guildConfig.bypassRoleId, guildConfig.bypassChannelId);
        } else {
interaction.reply({ content: 'No logging channel was configured.', ephemeral: true });
        }
    } else {
        const botMember = interaction.guild.members.me;

        if (!botMember) {
            interaction.reply({ content: 'Error: Unable to retrieve bot member information.', ephemeral: true });
            return;
        }

        const botPermissions = loggingChannel.permissionsFor(botMember);

        if (!botPermissions.has(PermissionFlagsBits.ViewChannel) || 
            !botPermissions.has(PermissionFlagsBits.SendMessages) || 
            !botPermissions.has(PermissionFlagsBits.EmbedLinks)) {


            const errorEmbed = new EmbedBuilder()
                .setTitle('Error')
                .setDescription(`Unable to set logging channel:

Permissions:
**View Channel:** ${botPermissions.has(PermissionFlagsBits.ViewChannel) ? '<:Yes:1259426548692418591>' : '<:No:1259426532921966702>'}
**Send Messages & Embeds:** ${botPermissions.has(PermissionFlagsBits.SendMessages) && botPermissions.has(PermissionFlagsBits.EmbedLinks) ? '<:Yes:1259426548692418591>' : '<:No:1259426532921966702>'}`)
                .setColor('#FF0000')
                .setThumbnail(botThumbnail)
                .setTimestamp();

            interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        if (guildConfig && guildConfig.loggingChannelId) {
            const currentLoggingChannel = await client.channels.fetch(guildConfig.loggingChannelId);
            if (currentLoggingChannel && loggingChannel.id !== guildConfig.loggingChannelId) {
            }
        }

        setGuildConfig(interaction.guild.id, loggingChannel.id, guildConfig.bypassRoleId, guildConfig.bypassChannelId);
await interaction.reply({ content: `Logging channel set to ${loggingChannel}`, ephemeral: true });
    }
    break;
        case 'bypass':
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                interaction.reply({ content: '`Administrator` permission not found.', ephemeral: true });
                return;
            }

            const bypassGuildConfig = getGuildConfig(guild.id);
            const roleOption = options.getRole('role');
            const channelOption = options.getChannel('channel');

            // Check if logging channel is set
            if (!bypassGuildConfig.loggingChannelId) {
                interaction.reply({ content: 'Please set a logging channel first. (Tip: set one using `/log`).', ephemeral: true });
                return;
            }
if (roleOption) {
    setGuildConfig(guild.id, bypassGuildConfig.loggingChannelId, roleOption.id, bypassGuildConfig.bypassChannelId);
    interaction.reply({ content: `<:Yes:1259426548692418591> <@&${roleOption.id}> added to bypass list.`, ephemeral: true });
} else if (channelOption) {
    setGuildConfig(guild.id, bypassGuildConfig.loggingChannelId, bypassGuildConfig.bypassRoleId, channelOption.id);
    interaction.reply({ content: `<:Yes:1259426548692418591> <#${channelOption.id}> added to bypass list.`, ephemeral: true });
} else {
    interaction.reply({ content: 'Please provide a role or a channel to bypass.', ephemeral: true });
}
            break;

case 'bypasslist':
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        interaction.reply({ content: '`Administrator` permission not found.', ephemeral: true });
        return;
    }

    const bypassListGuildConfig = getGuildConfig(guild.id); // Renamed variable for this case
    const { bypassRoleId, bypassChannelId } = getBypassList(guild.id);

    // Check if logging channel is set
    if (!bypassListGuildConfig.loggingChannelId) {
        interaction.reply({ content: 'Please set a logging channel first. (Tip: set one using `/log`).', ephemeral: true });
        return;
    }

    // Construct the embed description dynamically based on the bypassRoleId and bypassChannelId
    let description = 'No bypass roles or channels are set.';
    if (bypassRoleId || bypassChannelId) {
        description = '';
        if (bypassRoleId) {
            description += `**Roles:** <@&${bypassRoleId}>\n`;
        }
        if (bypassChannelId) {
            description += `**Channels:** <#${bypassChannelId}>\n`;
        }
    }

    const bypassListEmbed = new EmbedBuilder()
        .setTitle('Current Bypassed Roles & Channels')
        .setDescription(description)
        .setColor('#00FF00')
        .setTimestamp();

    interaction.reply({ embeds: [bypassListEmbed], ephemeral: true });
    break;

        case 'removebypass':
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                interaction.reply({ content: '`Administrator` permission not found.', ephemeral: true });
                return;
            }

            const removeBypassGuildConfig = getGuildConfig(guild.id); // Renamed variable for this case
            const roleToRemove = options.getRole('role');
            const channelToRemove = options.getChannel('channel');

            // Check if logging channel is set
            if (!removeBypassGuildConfig.loggingChannelId) {
                interaction.reply({ content: 'Please set a logging channel first. (Tip: set one using `/log`).', ephemeral: true });
                return;
            }

if (roleToRemove) {
    if (removeBypassGuildConfig.bypassRoleId === roleToRemove.id) {
        removeBypass(guild.id);
        interaction.reply({ content: `<:Yes:1259426548692418591> <@&${roleToRemove.id}> removed from bypass list.`, ephemeral: true });
    } else {
        interaction.reply({ content: `<:No:1259426532921966702> <@&${roleToRemove.id}> is not in the bypass list.`, ephemeral: true });
    }
} else if (channelToRemove) {
    if (removeBypassGuildConfig.bypassChannelId === channelToRemove.id) {
        removeBypass(guild.id);
        interaction.reply({ content: `<:Yes:1259426548692418591> <#${channelToRemove.id}> removed from bypass list.`, ephemeral: true });
    } else {
        interaction.reply({ content: `<:No:1259426532921966702> <#${channelToRemove.id}> is not in the bypass list.`, ephemeral: true });
    }
} else {
    interaction.reply({ content: 'Please provide a role or a channel to remove from the bypass list.', ephemeral: true });
}
            break;
            case 'info':
            const infoClientPing = Math.round(client.ws.ping);
            const Image = 'https://media.discordapp.net/attachments/1131985511662235650/1225495074935275540/standard.gif?ex=6621563a&is=660ee13a&hm=2683113ff9d1fec92065c1de79aa65e7d23cd82993530612eab71f1a8f0478b9&=';
            const numberOfUsers = client.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);
            const Color = Math.floor(Math.random() * 16777215).toString(16);

            if (!startTime) {
                interaction.reply('Bot is not ready yet.');
                return;
            }

            const InfocurrentTime = Date.now();
            const InfouptimeInSeconds = Math.floor((InfocurrentTime - startTime) / 1000);
            const InfouptimeDays = Math.floor(InfouptimeInSeconds / (3600 * 24));
            const InfouptimeHours = Math.floor((InfouptimeInSeconds % (3600 * 24)) / 3600);
            const InfouptimeMinutes = Math.floor((InfouptimeInSeconds % 3600) / 60);
            const InfouptimeSeconds = InfouptimeInSeconds % 60;

            InfouptimeString = `${InfouptimeDays}d ${InfouptimeHours}h ${InfouptimeMinutes}m ${InfouptimeSeconds}s`;

            const infoEmbed = new EmbedBuilder()
            .setTitle(':bar_chart: Logger bot statistics!')
            .setColor(`#${Color}`)
            .setThumbnail(botThumbnail)
            .setDescription(`
<:uptime:1262547944314241074> **Ping**: ${infoClientPing}ms
<:ping:1262548001113641010> **Uptime**: ${InfouptimeString}
<:servercount:1262548012484526211> **Server count**: ${numberOfServers} Servers
<:usercount:1262548020617019482> **User count**: ${numberOfUsers} Users
`)
            .setTimestamp()
            .setImage(Image);
            
     const infoButtons = new ActionRowBuilder()
        .addComponents(
    new ButtonBuilder()
      .setCustomId('details')
      .setLabel('Details')
      .setStyle(ButtonStyle.Success)
      );
            
interaction.reply({ embeds: [infoEmbed], components: [infoButtons], ephemeral: true });
            break;

case 'help':
  
            const helpEmbed = new EmbedBuilder()
                .setTitle('Commands Menu!')
                .setDescription(`\`/help\` • **Display this menu.**

\`/info\` • **Display useful information about the bot.**

\`/log <channel>\` • **Set the logging channel, leave clear to remove it 
(Requires __Administrator__ permission).**

\`/bypass <role> <channel>\` • **Set bypassed roles & channels 
(Requires __Administrator__ permission).**

\`/bypasslist\` • **Display current bypassed roles & channels.
(Requires __Administrator__ permission).**

\`/removebypass\` • **Remove a role / channel from bypass list 
(Requires __Administrator__ permission).**

\`/setlanguage\` • **Set the language logging language of the bot.
(Requires __Administrator__ permission).**

\`/suggest\` • **Suggest something to be sent to the developers.**

\`/ping\` • **Display client ping.**
`)
                .setColor('#059fbf')
                .setThumbnail(botThumbnail);

await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
            break;
    }
});
const { execSync } = require('child_process');
const os = require('os');
const { cpuUsage, memoryUsage } = process;
const si = require('systeminformation');

function getUptimeString() {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
}

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    const numberOfServers = client.guilds.cache.size;
    const numberOfUsers = client.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);
    let clientPing = Math.round(client.ws.ping);

    const nodeVersion = process.version;
    const botLibraryVersion = require('discord.js').version;
    const cpuUsagePercent = ((cpuUsage().user / 1000000) / os.cpus().length).toFixed(2) + '%'; // Percentage of CPU usage per core
    const memoryUsageMB = (memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + ' MB'; // Memory usage in MB
    const diskUsage = execSync('df -h | grep "/$"').toString().split(/\s+/)[4]; // Used disk space percentage (Unix-based)

    let networkUsageInbound = 'Not available';
    let networkUsageOutbound = 'Not available';
    try {
        const networkStats = await si.networkStats();
        if (networkStats.length > 0) {
            networkUsageInbound = (networkStats[0].rx_bytes / (1024 * 1024)).toFixed(2) + ' MB'; // Received bytes
            networkUsageOutbound = (networkStats[0].tx_bytes / (1024 * 1024)).toFixed(2) + ' MB'; // Transmitted bytes
        }
    } catch (error) {
        networkUsageInbound = 'Error fetching network stats';
        networkUsageOutbound = 'Error fetching network stats';
    }

    if (interaction.customId === 'details') {
        try {
            const detailedEmbed = new EmbedBuilder()
                .setTitle(':bar_chart: Logger bot **detailed** statistics!')
                .setDescription(`
**Ping**: ${clientPing}ms
**Uptime**: ${getUptimeString()}
**Server count**: ${numberOfServers} Servers
**User count**: ${numberOfUsers} Users
**Node.js Version**: ${nodeVersion}
**Bot Library**: discord.js
**Bot Library Version**: ${botLibraryVersion}
**CPU Usage**: ${cpuUsagePercent}
**Memory Usage**: ${memoryUsageMB}
**Disk Usage**: ${diskUsage}
**Network (Inbound) Usage**: ${networkUsageInbound}
**Network (Outbound) Usage**: ${networkUsageOutbound}
**Bot Invite link**: [Invite](https://discord.com/oauth2/authorize?client_id=1217843112840265808)
**Support Server**: [Support](https://discord.gg/k7gB8GQ8wJ)
**Developer**: @fwtrademark
                `);

            await interaction.reply({
                embeds: [detailedEmbed],
                ephemeral: true
            });
        } catch (error) {
            console.error('Error showing detailed embed.', error);
            await interaction.reply({
                content: 'Error showing detailed embed!',
                ephemeral: true
            });
        }
    }
});
client.on('messageCreate', async (message) => {
    const prefix = '-';

    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
        const botThumbnail = "https://media.discordapp.net/attachments/1131985511662235650/1227781895715291146/discord-avatar-128-LP4KS.gif?ex=6629a7ff&is=661732ff&hm=86bb90ef008815bd4ae9e2ad3af3275a966518ac4955e96b88e337b431a201ff&";

    switch (command) {
                    case 'servers':
                if (message.author.id !== '622382966504685580') return;
            
            const servers = client.guilds.cache.map(guild => guild.name).join("\n");
            
            const serverlistEmbed = new EmbedBuilder()
              .setTitle('Server List')
              .setDescription(servers)
              .setThumbnail(botThumbnail)
              .setTimestamp();
            
            message.reply(`${servers}`);
            break;

        case 'ping':
            let clientPing = Math.round(client.ws.ping);
            message.reply(`🏓 Pong! Ping is ${clientPing}ms.`);
            break;
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.id !== '622382966504685580') return;

    const args = message.content.trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === ';setstatus') {
        if (args.length < 3) {
            return message.channel.send('Incorrect usage. Please use: `;setstatus *status* *type* *activity*`');
        }

        try {
            const status = args[0].toLowerCase();
            const type = args[1].toLowerCase();
            let presence = args.slice(2).join(' ');

            if (presence.includes('<users>')) {
                presence = presence.replace('<users>', client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0));
            }
            
            if (presence.includes('<servers>')) {
                presence = presence.replace('<servers>', client.guilds.cache.size);
            }

            let activityType;
            switch (type) {
                case 'playing':
                    activityType = 1;
                    break;
                case 'watching':
                    activityType = 3;
                    break;
                case 'listening':
                    activityType = 2;
                    break;
                default:
                    return message.channel.send('Invalid activity type. Please use playing, watching, or listening.');
            }

            let botStatus;
            switch (status) {
                case 'dnd':
                    botStatus = 'dnd';
                    break;
                case 'online':
                    botStatus = 'online';
                    break;
                case 'idle':
                    botStatus = 'idle';
                    break;
                default:
                    return message.channel.send('Invalid bot status. Please use "online" or "idle".');
            }

            await client.user.setPresence({
                activities: [{ name: presence, type: activityType }],
                status: botStatus
            });
            await message.channel.send('<a:GPg_Checkmark:1226870486986657833> **Presence set successfully.**');
        } catch (error) {
            console.error('Error setting bot presence:', error);
            message.channel.send('An error occurred while setting bot presence.');
        }
    } else if (message.content.includes('<@1217843112840265808>')) {
        const Image = 'https://media.discordapp.net/attachments/1131985511662235650/1225495074935275540/standard.gif?ex=6621563a&is=660ee13a&hm=2683113ff9d1fec92065c1de79aa65e7d23cd82993530612eab71f1a8f0478b9&=';
        const numberOfServers = client.guilds.cache.size;
        const serverPFP = message.guild ? message.guild.iconURL({ dynamic: true }) : null;

        const mentionEmbed = new EmbedBuilder()
            .setTitle('Logger Bot')
            .setDescription(`Hey there! <:happy:1219744928041668759> I noticed you have mentioned me.

If you're looking for the commands menu, you can simply run \`/help\` to see my list of commands!

For additional support or if you have any questions, feel free to visit my support server [here](https://discord.gg/JMzu74KG3g)!

If you need further assistance, don't hesitate to reach out to me directly by DM'ing <@622382966504685580>.`)
            .setFooter({ text: `Currently logging in ${numberOfServers} servers!` })
            .setThumbnail(serverPFP)
            .setImage(Image)
            .setTimestamp();

        message.channel.send({ embeds: [mentionEmbed] });
    }
});
client.once('ready', async () => {
    const botThumbnail = "https://media.discordapp.net/attachments/1131985511662235650/1227781895715291146/discord-avatar-128-LP4KS.gif?ex=6629a7ff&is=661732ff&hm=86bb90ef008815bd4ae9e2ad3af3275a966518ac4955e96b88e337b431a201ff&";

    const channelId = '1228363859430084660';
    const channel = client.channels.cache.get(channelId);

   await channel.messages.fetch().then(messages => {
     const unpinnedMessages = messages.filter(message => !message.pinned);
     channel.bulkDelete(unpinnedMessages);
   }).catch(err => {
      console.error('Error deleting messages:', err);
  });


    const embed = new EmbedBuilder()
    .setTitle('Uptime:')
    .setThumbnail(botThumbnail)
    .setDescription(`**${getUptimeString()}**`)
    .setColor('#00FF00')
    .setTimestamp();

    const message = await channel.send({ embeds: [embed] });

    setInterval(() => {
    const updatedEmbed = new EmbedBuilder()
    .setTitle('Uptime:')
    .setThumbnail(botThumbnail)
    .setDescription(`**${getUptimeString()}**`)
    .setColor('#00FF00')
    .setTimestamp();
        
        message.edit({ embeds: [updatedEmbed] }).catch(console.error);
    }, 5000);
});

function getUptimeString() {
    const currentTime = Date.now();
    const uptimeInSeconds = Math.floor((currentTime - client.readyTimestamp) / 1000);
    const uptimeDays = Math.floor(uptimeInSeconds / (3600 * 24));
    const uptimeHours = Math.floor((uptimeInSeconds % (3600 * 24)) / 3600);
    const uptimeMinutes = Math.floor((uptimeInSeconds % 3600) / 60);
    const uptimeSeconds = uptimeInSeconds % 60;

    return `${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m ${uptimeSeconds}s`;
}
client.on('messageCreate', async message => {
  if (message.author.bot) return;

  if (message.content.startsWith('-eval') || message.content.startsWith('-lgeval')) {
    if (message.author.id !== '622382966504685580') return;

    let prefix = '';
    if (message.content.startsWith('-eval')) {
      prefix = '-eval';
    } else if (message.content.startsWith('-lgeval')) {
      prefix = '-lgeval';
    } else {
      return;
    }

    const code = message.content.slice(prefix.length).trim();

    if (!code) {
        return;
    }

    try {
        let evaled = eval(code);

        if (typeof evaled !== 'string') {
            evaled = require('util').inspect(evaled);
        }

        const successEmbed = new EmbedBuilder()
            .setTitle('Success')
            .setColor('#00FF00')
            .addFields(
                { name: 'Output', value: `\`\`\`js\n${evaled}\n\`\`\`` }
            );

        message.channel.send({ embeds: [successEmbed] });
        
    } catch (err) {
        const errorEmbed = new EmbedBuilder()
            .setTitle('Error')
            .setColor('#FF0000')
            .addFields(
                { name: 'Error', value: `\`\`\`js\n${err}\n\`\`\`` }
            );

        message.channel.send({ embeds: [errorEmbed] });
    }
  }
});
client.login(token);
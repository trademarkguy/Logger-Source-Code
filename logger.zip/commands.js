const { Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const path = require('path');
const config = require(path.join(__dirname, 'tokens.js'));
const token = config.Logger;
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.DirectMessageTyping,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.MessageContent
    ],
    shards: "auto",
    partials: [
        Partials.Message,
        Partials.Channel,
        Partials.GuildMember,
        Partials.Reaction,
        Partials.GuildScheduledEvent,
        Partials.User,
        Partials.ThreadMember
    ]
});
async function insertCommands(guild) {
    try {
        const commands = [
            {
                name: 'support',
                description: 'Reach Support!',
            },
            {
                name: 'help',
                description: 'Shows the commands list.',
            },
            {
                name: 'log',
                description: 'Set the logging channel.',
                options: [
                    {
                        name: 'channel',
                        description: 'Channel name',
                        type: 7, // Channel type
                        required: false
                    }
                ]
            },
            {
                name: 'bypass',
                description: 'Set a role / channel to be bypassed during logging.',
                options: [
                    {
                        name: 'role',
                        description: 'Role to be bypassed',
                        type: 8, // Role type
                        required: false
                    },
                    {
                        name: 'channel',
                        description: 'Channel to be bypassed',
                        type: 7, // Channel type
                        required: false
                    }
                ]
            },
            {
                name: 'bypasslist',
                description: 'Show the current bypassed roles & channels.',
            },
            {
                name: 'removebypass',
                description: 'Remove a role / channel from bypass list.',
                options: [
                    {
                        name: 'role',
                        description: 'Role to be removed from bypass list',
                        type: 8, // Role type
                        required: false
                    },
                    {
                        name: 'channel',
                        description: 'Channel to be removed from bypass list',
                        type: 7, // Channel type
                        required: false
                    }
                ]
            },
            {
                name: 'suggest',
                description: 'Send a suggestion to the developers.',
                options: [
                    {
                        name: 'suggestion',
                        description: 'Suggestion to be sent.',
                        type: 3, // String type
                        required: true
                    }
                ]
            },
            {
                name: 'ping',
                description: 'Show client latency.'
            },
            {
                name: 'info',
                description: 'Display useful info about the bot.'
            },
            {
                name: 'setlanguage',
                description: 'Set the preferred language for logging messages.',
                options: [
                    {
                        name: 'language',
                        description: 'Select a language',
                        type: 3, // String type
                        required: true,
                        choices: [
                            { name: 'English', value: 'en' },
                            { name: 'French', value: 'fr' },
                            { name: 'German', value: 'de' },
                            { name: 'Spanish', value: 'es' },
                            { name: 'Hindi', value: 'hi' }
                        ]
                    }
                ]
            },
        ];

        await guild.commands.set(commands);
    } catch (error) {
        console.error('Error setting slash commands:', error);
    }
}

async function insertCommandsToAllGuilds() {
    try {
        await Promise.all(client.guilds.cache.map(guild => insertCommands(guild)));
        console.log('Slash commands registered for all guilds.');
    } catch (error) {
        console.error('Error inserting slash commands to all guilds:', error);
    }
}

client.on('guildCreate', async guild => {
    await insertCommands(guild);
});

client.once('ready', async () => {
    console.log(`Commands Successfully Deployed`);
    const numberOfServers = client.guilds.cache.size;
    const users = client.guilds.cache.reduce((total, guild) => total + guild.memberCount, 0);
    client.user.setPresence({
        activities: [{ name: `${numberOfServers} servers and ${users} users!`, type: 3 }],
        status: 'dnd'
    });
    await insertCommandsToAllGuilds();
});
client.login(token);